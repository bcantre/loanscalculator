package com.hoegh.loanscalc.processor;

import com.hoegh.loanscalc.dto.AmortizationSummaryDto;
import com.hoegh.loanscalc.dto.LoanOptionsDto;

public class BusinessLoansProcessor extends LoansProcessor {

	public BusinessLoansProcessor(LoanOptionsDto options) {
		super(options);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected AmortizationSummaryDto calculate() {
		// TODO Auto-generated method stub
		return null;
	}

}
