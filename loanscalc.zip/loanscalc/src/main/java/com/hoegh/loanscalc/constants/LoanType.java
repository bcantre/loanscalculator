package com.hoegh.loanscalc.constants;

public enum LoanType {
	HOUSE, CAR, BUSINESS, PERSONAL
}
