package com.hoegh.loanscalc.constants;

public class WebResourceConstants {
	public static final String LOANS_MAIN = "loans_main";
	
	private WebResourceConstants() {}
}
